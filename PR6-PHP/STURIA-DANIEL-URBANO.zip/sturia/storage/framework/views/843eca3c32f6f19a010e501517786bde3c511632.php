<div>
    <footer  class="bg-danger text-white py-3 container" style="margin-top: 3rem">
        <div class="container">
            <h3>Sturia Planes</h3>
        </div>
    </footer>
</div><?php /**PATH C:\Users\Orejuski pc\Desktop\DAW2\PR6-PHP\sturia\resources\views/footer.blade.php ENDPATH**/ ?>