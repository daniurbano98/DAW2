<div class="container">
  <header style="margin-top: 3rem; margin-bottom: 3rem">
    <nav class="navbar navbar-expand-lg navbar-light" style="background-color: rgb(220,53,69)">
        <h2 class="navbar-brand" style="color: white">STURIA</h2>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
          <ul class="navbar-nav">
            <li class="nav-item">
              <a class="nav-link" href="<?php echo e(route('index')); ?>" style="color:white">Listar</a>
            </li>
          </ul>
        </div>
      </nav> 
  </header>
</div>
<?php /**PATH C:\Users\Orejuski pc\Desktop\DAW2\PR6-PHP\sturia\resources\views/header.blade.php ENDPATH**/ ?>