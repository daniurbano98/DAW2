<div>
    <footer  class="bg-danger text-white py-3 container" style="margin-top: 3rem">
        <div class="container">
            <h3>Sturia Planes</h3>
        </div>
    </footer>
</div>